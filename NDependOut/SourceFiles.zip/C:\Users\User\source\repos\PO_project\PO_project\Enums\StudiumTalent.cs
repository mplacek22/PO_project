﻿namespace PO_project.Enums
{
	public enum StudiumTalent
	{
		Matematyka = 0,
		Fizyka = 1
	}
}
